var app = new PIXI.Application(2000,2000);
document.body.appendChild(app.view);

PIXI.loader
    .add('./images/spritesheet.json')
    .load(onAssetsLoaded);

function onAssetsLoaded()

{
        var frames = [];
        let bg;
         bg = PIXI.Texture.fromImage("background.png");
         background = new PIXI.Sprite(bg);
         app.stage.addChild(background);

        let anim;
    for (var i = 1; i < 9; i++) {
        var val = i < 10 ? '0' + i : i;
        frames.push(PIXI.Texture.fromFrame('capguy_' + val + '.png'));
    }

    anim = new PIXI.extras.AnimatedSprite(frames);
    anim.x = 100;
    anim.y = 400;
    anim.anchor.set(0.5);
    anim.animationSpeed = 0.1;
    anim.play();

    app.stage.addChild(anim);
    app.ticker.add(function() {
    anim.rotation += 0.01;
    //anim.x += 0.3;
    });
}
